﻿import { default as myHealthModule} from './app.module';

angular.bootstrap(document.getElementById('app'), [myHealthModule]);