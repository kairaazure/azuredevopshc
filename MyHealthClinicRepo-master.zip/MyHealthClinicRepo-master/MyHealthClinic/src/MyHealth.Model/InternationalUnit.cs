﻿namespace MyHealth.Model
{
    public enum InternationalUnit
    {
        Milligrams = 1,
        Milliliters = 2
    }
}
